﻿Cómo jugar.txt
Para jugar Space Invaders:

1. Requisitos:
   - Tener Java instalado (JRE o JDK) versión 8 o superior

2. Instrucciones:
   - Opción 1: Doble clic en SpaceInvaders.jar
   - Opción 2: Abrir terminal y ejecutar: java -jar SpaceInvaders.jar

3. Importante:
   - No mover ni eliminar la carpeta 'lib'
   - Mantener todos los archivos juntos
